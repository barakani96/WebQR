self.__precacheManifest = [
  {
    "url": "main.c9f414e553687879682c.bundle.js"
  },
  {
    "revision": "6135d25d03e92c318bbb",
    "url": "styles.css"
  }
];